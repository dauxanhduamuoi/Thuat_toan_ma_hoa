/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_03;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


/**
 *
 * @author LENOVO
 */
public class frm_ECC_Signature extends javax.swing.JFrame {
    
    
    // Doi tuong xu ly chu ky so ECDSA
    private final ECCSignature ecdsa = new ECCSignature();

    // Cac o van ban
    private JTextArea txt_public;
    private JTextArea txt_private;
    private JTextArea txt_message;
    private JTextArea txt_signature;

    // Cac nut chuc nang
    private JButton btn_generate;
    private JButton btn_savekeys;
    private JButton btn_loadkeys;
    private JButton btn_sign;
    private JButton btn_verify;

    // Nhan hien thi ket qua
    private JLabel lbl_result;
    private JLabel lbl_status;

    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frm_ECC_Signature.class.getName());

    /**
     * Creates new form frm_ECC_Signature
     */
    public frm_ECC_Signature() {
        initComponents();
        taoGiaoDienECDSA();
        setLocationRelativeTo(null);
    }
    
    
    // ==========================================
    // 1. TAO GIAO DIEN ECDSA
    // ==========================================
    private void taoGiaoDienECDSA() {

        setTitle("ECDSA Signature");

        setDefaultCloseOperation(
                javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        setSize(850, 740);
        setMinimumSize(new Dimension(700, 600));

        JPanel root = new JPanel(
                new BorderLayout(10, 10));

        root.setBorder(
                BorderFactory.createEmptyBorder(
                        18, 20, 18, 20));

        setContentPane(root);

        // Tieu de
        JLabel title = new JLabel(
                "CHỮ KÝ SỐ ECDSA (SHA256withECDSA)");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 20));

        root.add(title, BorderLayout.NORTH);

        // Panel noi dung
        JPanel content = new JPanel();

        content.setLayout(
                new BoxLayout(content, BoxLayout.Y_AXIS));

        JScrollPane mainScroll = new JScrollPane(content);
        mainScroll.setBorder(null);

        root.add(mainScroll, BorderLayout.CENTER);

        // ----------------------------------
        // PUBLIC KEY
        // ----------------------------------
        txt_public = taoOText(2, false);

        themOText(
                content, "Public key:", txt_public, 65);

        // ----------------------------------
        // PRIVATE KEY
        // ----------------------------------
        txt_private = taoOText(2, false);

        themOText(
                content, "Private key:", txt_private, 65);

        // ----------------------------------
        // CAC NUT QUAN LY KHOA
        // ----------------------------------
        JPanel keyButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        keyButtons.setAlignmentX(LEFT_ALIGNMENT);

        keyButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 44));

        btn_generate = new JButton("Generate Keys");
        btn_savekeys = new JButton("Save Keys");
        btn_loadkeys = new JButton("Load Keys");

        keyButtons.add(btn_generate);
        keyButtons.add(btn_savekeys);
        keyButtons.add(btn_loadkeys);

        content.add(keyButtons);
        content.add(Box.createVerticalStrut(14));

        // ----------------------------------
        // MESSAGE
        // ----------------------------------
        txt_message = taoOText(3, true);

        themOText(
                content, "Message:", txt_message, 100);

        // ----------------------------------
        // SIGNATURE
        // ----------------------------------
        txt_signature = taoOText(3, true);

        themOText(
                content, "Signature:", txt_signature, 115);

        // ----------------------------------
        // NUT SIGN VA VERIFY
        // ----------------------------------
        JPanel actionButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        actionButtons.setAlignmentX(LEFT_ALIGNMENT);

        actionButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 45));

        btn_sign = new JButton("Sign");
        btn_verify = new JButton("Verify");

        actionButtons.add(btn_sign);
        actionButtons.add(btn_verify);

        content.add(actionButtons);

        // ----------------------------------
        // KET QUA VALID / INVALID
        // ----------------------------------
        JPanel footer = new JPanel();

        footer.setLayout(
                new BoxLayout(footer, BoxLayout.Y_AXIS));

        lbl_result = new JLabel(" ");

        lbl_result.setFont(
                new Font("Segoe UI", Font.BOLD, 24));

        lbl_result.setAlignmentX(LEFT_ALIGNMENT);

        footer.add(lbl_result);
        footer.add(Box.createVerticalStrut(6));

        // Trang thai
        lbl_status = new JLabel(
                "Bấm Generate Keys hoặc Load Keys.");

        lbl_status.setAlignmentX(LEFT_ALIGNMENT);

        footer.add(lbl_status);

        root.add(footer, BorderLayout.SOUTH);

        // ----------------------------------
        // GAN SU KIEN CAC NUT
        // ----------------------------------
        btn_generate.addActionListener(
                e -> xuLyTaoKhoa());

        btn_savekeys.addActionListener(
                e -> xuLyLuuKhoa());

        btn_loadkeys.addActionListener(
                e -> xuLyNapKhoa());

        btn_sign.addActionListener(
                e -> xuLyKy());

        btn_verify.addActionListener(
                e -> xuLyXacMinh());
    }

    // ==========================================
    // 2. TAO O TEXT
    // ==========================================
    private JTextArea taoOText(
            int rows, boolean editable) {

        JTextArea area = new JTextArea(rows, 55);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(editable);

        area.setFont(
                new Font("Consolas", Font.PLAIN, 13));

        return area;
    }

    // ==========================================
    // 3. THEM O TEXT VAO GIAO DIEN
    // ==========================================
    private void themOText(
            JPanel panel,
            String label,
            JTextArea area,
            int height) {

        JLabel lbl = new JLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);

        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));

        JScrollPane scroll = new JScrollPane(area);

        scroll.setAlignmentX(LEFT_ALIGNMENT);

        scroll.setPreferredSize(
                new Dimension(700, height));

        scroll.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, height));

        panel.add(scroll);
        panel.add(Box.createVerticalStrut(14));
    }

    // ==========================================
    // 4. HIEN THI CAP KHOA
    // ==========================================
    private void showKeys() {

        txt_public.setText(
                ecdsa.getPublicKeyBase64());

        txt_private.setText(
                ecdsa.getPrivateKeyBase64());

        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    // ==========================================
    // 5. GENERATE KEYS
    // ==========================================
    private void xuLyTaoKhoa() {

        try {
            ecdsa.generateKeys();

            showKeys();

            lbl_result.setText(" ");

            lbl_status.setText(
                    "Đã tạo cặp khóa mới. "
                    + "Chữ ký cũ không hợp lệ với khóa mới.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Không tạo được khóa: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 6. SAVE KEYS
    // ==========================================
    private void xuLyLuuKhoa() {

        if (txt_public.getText().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this, "Chưa có khóa để lưu.");

            return;
        }

        String content = CryptoSupport.toKeyFile(
                txt_public.getText(),
                txt_private.getText()
        );

        String path = FileTextIO.saveString(
                this,
                content,
                "ecdsa_keys.txt"
        );

        if (path != null) {

            lbl_status.setText(
                    "Đã lưu khóa vào: "
                    + path
                    + " (giữ bí mật dòng PRIVATE).");
        }
    }

    // ==========================================
    // 7. LOAD KEYS
    // ==========================================
    private void xuLyNapKhoa() {

        String content = FileTextIO.openString(this);

        if (content == null) {
            return;
        }

        try {
            String[] keys =
                    CryptoSupport.fromKeyFile(content);

            ecdsa.loadKeys(keys[0], keys[1]);

            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);

            txt_public.setCaretPosition(0);
            txt_private.setCaretPosition(0);

            lbl_result.setText(" ");

            lbl_status.setText(
                    "Đã nạp khóa từ tệp.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Tệp khóa không hợp lệ: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 8. SIGN - KY BANG PRIVATE KEY
    // ==========================================
    private void xuLyKy() {

        String message = txt_message.getText();

        try {

            String signature = ecdsa.sign(message);

            txt_signature.setText(signature);
            txt_signature.setCaretPosition(0);

            lbl_result.setText(" ");

            lbl_status.setText(
                    "Đã ký thông điệp bằng KHÓA RIÊNG.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Ký thất bại: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 9. VERIFY - XAC MINH BANG PUBLIC KEY
    // ==========================================
    private void xuLyXacMinh() {

        String message = txt_message.getText();

        String signature =
                txt_signature.getText().trim();

        if (signature.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Chưa có chữ ký. Hãy bấm Sign trước.");

            return;
        }

        try {

            boolean ok = ecdsa.verify(
                    message, signature);

            if (ok) {

                lbl_result.setText("VALID");

                lbl_result.setForeground(
                        new Color(0, 128, 0));

                lbl_status.setText(
                        "Chữ ký hợp lệ. "
                        + "Thông điệp chưa bị thay đổi.");

            } else {

                lbl_result.setText("INVALID");

                lbl_result.setForeground(Color.RED);

                lbl_status.setText(
                        "Chữ ký KHÔNG hợp lệ. "
                        + "Thông điệp bị sửa hoặc sai khóa.");
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Xác minh thất bại: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frm_ECC_Signature().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
