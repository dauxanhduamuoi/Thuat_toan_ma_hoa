/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.KeyAgreement;

/**
 * Mã hóa ECC kiểu ECIES:
 * ECDH (secp256r1) + HKDF-SHA256 + AES-256-GCM.
 *
 * Bản mã = Base64(
 *     Khóa công khai tạm 91 byte
 *     + salt 16 byte
 *     + nonce 12 byte
 *     + dữ liệu AES-GCM
 * )
 */
public final class ECCCipher {

    private static final byte[] INFO =
            CryptoSupport.utf8("LAB3-ECC-AESGCM");

    private static final int EPH = 91;

    private PublicKey publicKey;
    private PrivateKey privateKey;

    // Tạo cặp khóa ECC mới
    private static KeyPair newPair() throws Exception {

        KeyPairGenerator gen =
                KeyPairGenerator.getInstance("EC");

        gen.initialize(
                new ECGenParameterSpec("secp256r1"));

        return gen.generateKeyPair();
    }

    // Tạo cặp khóa công khai và khóa riêng
    public void generateKeys() throws Exception {

        KeyPair p = newPair();

        publicKey = p.getPublic();
        privateKey = p.getPrivate();
    }

    // Mã hóa dữ liệu bằng ECC
    public String encrypt(String plaintext) throws Exception {

        if (publicKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa: bấm Generate Keys hoặc Load Keys.");
        }

        // Bước 1: Tạo cặp khóa tạm
        KeyPair eph = newPair();

        // Bước 2: Tính bí mật chung ECDH
        KeyAgreement ka =
                KeyAgreement.getInstance("ECDH");

        ka.init(eph.getPrivate());
        ka.doPhase(publicKey, true);

        // Bước 3: Sinh salt, nonce và khóa AES
        byte[] salt = CryptoSupport.randomBytes(16);
        byte[] nonce = CryptoSupport.randomBytes(12);

        byte[] aesKey = CryptoSupport.hkdf(
                ka.generateSecret(), salt, INFO);

        // Bước 4: Mã hóa bằng AES-GCM
        byte[] data = CryptoSupport.gcmEncrypt(
                aesKey,
                nonce,
                CryptoSupport.utf8(plaintext)
        );

        // Bước 5: Ghép dữ liệu và chuyển Base64
        return CryptoSupport.b64(
                CryptoSupport.concat(
                        eph.getPublic().getEncoded(),
                        salt,
                        nonce,
                        data
                )
        );
    }

    // Giải mã dữ liệu
    public String decrypt(String ciphertext) throws Exception {

        if (privateKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa riêng.");
        }

        byte[] all = CryptoSupport.unb64(ciphertext);

        // Tách khóa công khai tạm
        PublicKey eph = KeyFactory.getInstance("EC")
                .generatePublic(
                        new X509EncodedKeySpec(
                                CryptoSupport.slice(all, 0, EPH)
                        )
                );

        // Tách salt, nonce và dữ liệu mã hóa
        byte[] salt =
                CryptoSupport.slice(all, EPH, EPH + 16);

        byte[] nonce =
                CryptoSupport.slice(all, EPH + 16, EPH + 28);

        byte[] data =
                CryptoSupport.slice(all, EPH + 28, all.length);

        // Tính lại bí mật chung ECDH
        KeyAgreement ka =
                KeyAgreement.getInstance("ECDH");

        ka.init(privateKey);
        ka.doPhase(eph, true);

        // Khôi phục khóa AES
        byte[] aesKey = CryptoSupport.hkdf(
                ka.generateSecret(), salt, INFO);

        // Giải mã AES-GCM
        return CryptoSupport.text(
                CryptoSupport.gcmDecrypt(
                        aesKey, nonce, data)
        );
    }

    // Lấy khóa công khai Base64
    public String getPublicKeyBase64() {
        return CryptoSupport.b64(publicKey.getEncoded());
    }

    // Lấy khóa riêng Base64
    public String getPrivateKeyBase64() {
        return CryptoSupport.b64(privateKey.getEncoded());
    }

    // Nạp khóa từ dữ liệu Base64
    public void loadKeys(
            String publicB64, String privateB64) throws Exception {

        KeyFactory kf = KeyFactory.getInstance("EC");

        publicKey = kf.generatePublic(
                new X509EncodedKeySpec(
                        CryptoSupport.unb64(publicB64)
                )
        );

        privateKey = privateB64.isBlank()
                ? null
                : kf.generatePrivate(
                        new PKCS8EncodedKeySpec(
                                CryptoSupport.unb64(privateB64)
                        )
                );
    }
}
