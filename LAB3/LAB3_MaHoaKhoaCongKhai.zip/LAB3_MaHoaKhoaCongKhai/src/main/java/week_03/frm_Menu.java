/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_03;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


/**
 *
 * @author LENOVO
 */
public class frm_Menu extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frm_Menu.class.getName());

    /**
     * Creates new form frm_Menu
     */
    public frm_Menu() {
        initComponents();
        taoGiaoDienMenu();
        setLocationRelativeTo(null);
    }
    
    // ==========================================
    // KHAI BAO CAC NUT TREN MENU
    // ==========================================
    private JButton btn_rsa;
    private JButton btn_ecc;
    private JButton btn_rsaaes;
    private JButton btn_signature;
    private JButton btn_sql;
    private JButton btn_history;

    // ==========================================
    // 1. TAO GIAO DIEN MENU CHINH
    // ==========================================
    private void taoGiaoDienMenu() {

        setTitle("LAB 3 - Mã hóa khóa công khai");

        // Dong menu la thoat chuong trinh
        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE);

        setSize(750, 280);
        setMinimumSize(new Dimension(680, 250));

        // Panel chinh
        JPanel root = new JPanel(
                new BorderLayout(10, 15));

        root.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 22, 20, 22));

        setContentPane(root);

        // ======================================
        // TIEU DE
        // ======================================
        JPanel header = new JPanel(
                new BorderLayout(0, 8));

        JLabel title = new JLabel(
                "LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 22));

        header.add(title, BorderLayout.NORTH);

        JLabel subtitle = new JLabel(
                "Chọn một bài để mở form tương ứng "
                + "(bài 3.1 chạy RSADemo.java bằng Run File):");

        subtitle.setFont(
                new Font("Segoe UI", Font.PLAIN, 12));

        header.add(subtitle, BorderLayout.SOUTH);

        root.add(header, BorderLayout.NORTH);

        // ======================================
        // PANEL CHUA 6 NUT
        // ======================================
        JPanel buttons = new JPanel(
                new GridLayout(2, 3, 12, 12));

        // Tao cac nut
        btn_rsa = new JButton("3.2 RSA (Swing)");

        btn_ecc = new JButton("3.3 ECC");

        btn_rsaaes = new JButton("3.4 RSA + AES");

        btn_signature = new JButton(
                "3.5 Chữ ký ECDSA");

        btn_sql = new JButton(
                "Kết nối SQL Server");

        btn_history = new JButton(
                "Xem lịch sử");

        // Font chung cho cac nut
        Font buttonFont =
                new Font("Segoe UI", Font.BOLD, 13);

        JButton[] allButtons = {
            btn_rsa,
            btn_ecc,
            btn_rsaaes,
            btn_signature,
            btn_sql,
            btn_history
        };

        for (JButton btn : allButtons) {
            btn.setFont(buttonFont);
            btn.setFocusPainted(false);
        }

        // Dua cac nut vao menu
        buttons.add(btn_rsa);
        buttons.add(btn_ecc);
        buttons.add(btn_rsaaes);

        buttons.add(btn_signature);
        buttons.add(btn_sql);
        buttons.add(btn_history);

        root.add(buttons, BorderLayout.CENTER);

        // ======================================
        // 2. NUT RSA
        // ======================================
        btn_rsa.addActionListener(e -> {

            new frm_RSA().setVisible(true);

        });

        // ======================================
        // 3. NUT ECC
        // ======================================
        btn_ecc.addActionListener(e -> {

            new frm_ECC().setVisible(true);

        });

        // ======================================
        // 4. NUT RSA + AES
        // ======================================
        btn_rsaaes.addActionListener(e -> {

            new frm_RSA_AES().setVisible(true);

        });

        // ======================================
        // 5. NUT CHU KY SO ECDSA
        // ======================================
        btn_signature.addActionListener(e -> {

            new frm_ECC_Signature().setVisible(true);

        });

        // ======================================
        // 6. NUT KET NOI SQL SERVER
        // ======================================
        btn_sql.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    this,
                    "Chức năng SQL Server chưa được thực hiện.\n"
                    + "Bạn có thể bổ sung sau.",
                    "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE
            );

        });

        // ======================================
        // 7. NUT XEM LICH SU
        // ======================================
        btn_history.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    this,
                    "Chức năng xem lịch sử chưa được thực hiện.\n"
                    + "Cần kết nối SQL Server trước.",
                    "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE
            );

        });
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
