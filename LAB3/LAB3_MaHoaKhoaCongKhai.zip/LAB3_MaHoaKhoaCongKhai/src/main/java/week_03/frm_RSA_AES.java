/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_03;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


/**
 *
 * @author LENOVO
 */
public class frm_RSA_AES extends javax.swing.JFrame {
    
    private final RSA_AES_Cipher hybrid =
            new RSA_AES_Cipher();

    private JTextArea txt_public;
    private JTextArea txt_private;
    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;

    private JButton btn_generate;
    private JButton btn_savekeys;
    private JButton btn_loadkeys;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_tamper;

    private JLabel lbl_status;

    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frm_RSA_AES.class.getName());

    /**
     * Creates new form frm_RSA_AES
     */
    public frm_RSA_AES() {
        initComponents();
        taoGiaoDienRSAAES();
        setLocationRelativeTo(null);
    }
    
    
    // ========================================
    // 1. TAO GIAO DIEN RSA + AES
    // ========================================
    private void taoGiaoDienRSAAES() {

        setTitle("RSA + AES Cipher");

        setDefaultCloseOperation(
                javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        setSize(900, 760);
        setMinimumSize(new Dimension(720, 600));

        JPanel root = new JPanel(
                new BorderLayout(10, 10));

        root.setBorder(
                BorderFactory.createEmptyBorder(
                        18, 20, 18, 20));

        setContentPane(root);

        JLabel title = new JLabel(
                "HỆ MÃ LAI RSA + AES-GCM (VĂN BẢN DÀI)");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 20));

        root.add(title, BorderLayout.NORTH);

        // Panel nội dung
        JPanel content = new JPanel();

        content.setLayout(
                new BoxLayout(content, BoxLayout.Y_AXIS));

        JScrollPane mainScroll =
                new JScrollPane(content);

        mainScroll.setBorder(null);

        root.add(mainScroll, BorderLayout.CENTER);

        // Public Key
        txt_public = taoOText(2, false);

        themOText(
                content, "Public key:", txt_public, 65);

        // Private Key
        txt_private = taoOText(2, false);

        themOText(
                content, "Private key:", txt_private, 65);

        // Các nút quản lý khóa
        JPanel keyButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        keyButtons.setAlignmentX(LEFT_ALIGNMENT);
        keyButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 44));

        btn_generate = new JButton("Generate Keys");
        btn_savekeys = new JButton("Save Keys");
        btn_loadkeys = new JButton("Load Keys");

        keyButtons.add(btn_generate);
        keyButtons.add(btn_savekeys);
        keyButtons.add(btn_loadkeys);

        content.add(keyButtons);
        content.add(Box.createVerticalStrut(14));

        // Plaintext
        txt_plaintext = taoOText(5, true);

        themOText(
                content, "Plaintext:", txt_plaintext, 130);

        // Ciphertext
        txt_ciphertext = taoOText(6, true);

        themOText(
                content, "Ciphertext:", txt_ciphertext, 150);

        // Các nút mã hóa và giải mã
        JPanel actionButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        actionButtons.setAlignmentX(LEFT_ALIGNMENT);
        actionButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 46));

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");

        btn_tamper = new JButton(
                "Sửa 1 ký tự bản mã");

        actionButtons.add(btn_encrypt);
        actionButtons.add(btn_decrypt);
        actionButtons.add(btn_tamper);

        content.add(actionButtons);

        // Trạng thái
        lbl_status = new JLabel(
                "Bấm Generate Keys hoặc Load Keys.");

        lbl_status.setBorder(
                BorderFactory.createEmptyBorder(8, 0, 3, 0));

        root.add(lbl_status, BorderLayout.SOUTH);

        // Gắn các sự kiện
        btn_generate.addActionListener(
                e -> xuLyTaoKhoa());

        btn_savekeys.addActionListener(
                e -> xuLyLuuKhoa());

        btn_loadkeys.addActionListener(
                e -> xuLyNapKhoa());

        btn_encrypt.addActionListener(
                e -> xuLyMaHoa());

        btn_decrypt.addActionListener(
                e -> xuLyGiaiMa());

        btn_tamper.addActionListener(
                e -> xuLySuaBanMa());
    }

    // ========================================
    // 2. HAM HO TRO TAO O TEXT
    // ========================================
    private JTextArea taoOText(
            int rows, boolean editable) {

        JTextArea area = new JTextArea(rows, 55);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(editable);

        area.setFont(
                new Font("Consolas", Font.PLAIN, 13));

        return area;
    }

    // ========================================
    // 3. THEM O TEXT VAO GIAO DIEN
    // ========================================
    private void themOText(
            JPanel panel,
            String label,
            JTextArea area,
            int height) {

        JLabel lbl = new JLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);

        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));

        JScrollPane scroll = new JScrollPane(area);

        scroll.setAlignmentX(LEFT_ALIGNMENT);

        scroll.setPreferredSize(
                new Dimension(700, height));

        scroll.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, height));

        panel.add(scroll);
        panel.add(Box.createVerticalStrut(14));
    }

    // ========================================
    // 4. HIEN THI KHOA
    // ========================================
    private void showKeys() {

        txt_public.setText(
                hybrid.getPublicKeyBase64());

        txt_private.setText(
                hybrid.getPrivateKeyBase64());

        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    // ========================================
    // 5. GENERATE KEYS
    // ========================================
    private void xuLyTaoKhoa() {

        try {
            hybrid.generateKeys();

            showKeys();

            lbl_status.setText(
                    "Đã tạo cặp khóa mới. "
                    + "Bản mã cũ không giải được bằng khóa mới.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Không tạo được khóa: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ========================================
    // 6. SAVE KEYS
    // ========================================
    private void xuLyLuuKhoa() {

        if (txt_public.getText().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this, "Chưa có khóa để lưu.");

            return;
        }

        String content = CryptoSupport.toKeyFile(
                txt_public.getText(),
                txt_private.getText()
        );

        String path = FileTextIO.saveString(
                this,
                content,
                "rsa_aes_keys.txt"
        );

        if (path != null) {
            lbl_status.setText(
                    "Đã lưu khóa vào: " + path
                    + " (giữ bí mật dòng PRIVATE).");
        }
    }

    // ========================================
    // 7. LOAD KEYS
    // ========================================
    private void xuLyNapKhoa() {

        String content = FileTextIO.openString(this);

        if (content == null) {
            return;
        }

        try {
            String[] keys =
                    CryptoSupport.fromKeyFile(content);

            hybrid.loadKeys(keys[0], keys[1]);

            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);

            txt_public.setCaretPosition(0);
            txt_private.setCaretPosition(0);

            lbl_status.setText(
                    "Đã nạp khóa từ tệp.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Tệp khóa không hợp lệ: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ========================================
    // 8. ENCRYPT
    // ========================================
    private void xuLyMaHoa() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa.");

            return;
        }

        try {
            String ciphertext =
                    hybrid.encrypt(plaintext);

            txt_ciphertext.setText(ciphertext);
            txt_ciphertext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã mã hóa RSA-AES ("
                    + ciphertext.length()
                    + " ký tự Base64).");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ========================================
    // 9. DECRYPT
    // ========================================
    private void xuLyGiaiMa() {

        String ciphertext =
                txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã.");

            return;
        }

        try {
            String plaintext =
                    hybrid.decrypt(ciphertext);

            txt_plaintext.setText(plaintext);
            txt_plaintext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã giải mã RSA-AES thành công.");

        } catch (Exception ex) {

            lbl_status.setText(
                    "Giải mã RSA-AES THẤT BẠI "
                    + "(sai khóa hoặc bản mã bị sửa).");

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: "
                    + ex.getMessage(),
                    "Giải mã thất bại",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ========================================
    // 10. SUA 1 KY TU BAN MA
    // ========================================

private void xuLySuaBanMa() {

    String c = txt_ciphertext.getText().trim();

    if (c.isEmpty()) {
        JOptionPane.showMessageDialog(
                this, "Hãy Encrypt trước.");
        return;
    }

    try {
        // Chuyển Base64 về mảng byte
        byte[] all = CryptoSupport.unb64(c);

        // RSA-2048: 256 byte khóa AES đã bọc
        // AES-GCM: 12 byte nonce
        int dataStart = 256 + 12;

        if (all.length <= dataStart) {
            JOptionPane.showMessageDialog(
                    this, "Bản mã không hợp lệ.");
            return;
        }

        // Chọn một byte trong phần dữ liệu AES-GCM
        int i = dataStart
                + (all.length - dataStart) / 2;

        // Thay đổi đúng 1 bit của bản mã
        all[i] ^= 1;

        // Chuyển lại thành Base64
        txt_ciphertext.setText(
                CryptoSupport.b64(all));

        txt_ciphertext.setCaretPosition(0);

        lbl_status.setText(
                "Đã sửa bản mã AES-GCM. "
                + "Bấm Decrypt để kiểm tra tính toàn vẹn.");

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(
                this,
                "Không sửa được bản mã: "
                + ex.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
    }
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frm_RSA_AES().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
