/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * Chu ky so ECDSA.
 *
 * Thuat toan: SHA256withECDSA
 * Duong cong: secp256r1
 *
 * KY bang khoa rieng.
 * XAC MINH bang khoa cong khai.
 */
public final class ECCSignature {

    private PublicKey publicKey;
    private PrivateKey privateKey;

    // =========================================
    // 1. TAO CAP KHOA ECDSA
    // =========================================
    public void generateKeys() throws Exception {

        KeyPairGenerator gen =
                KeyPairGenerator.getInstance("EC");

        gen.initialize(
                new ECGenParameterSpec("secp256r1"));

        KeyPair p = gen.generateKeyPair();

        publicKey = p.getPublic();
        privateKey = p.getPrivate();
    }

    // =========================================
    // 2. KY THONG DIEP BANG PRIVATE KEY
    // =========================================
    public String sign(String message) throws Exception {

        if (privateKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa riêng: bấm Generate Keys hoặc Load Keys.");
        }

        Signature s =
                Signature.getInstance("SHA256withECDSA");

        // Su dung khoa rieng de ky
        s.initSign(privateKey);

        // Dua thong diep vao qua trinh ky
        s.update(CryptoSupport.utf8(message));

        // Tao chu ky va chuyen sang Base64
        return CryptoSupport.b64(s.sign());
    }

    // =========================================
    // 3. XAC MINH CHU KY BANG PUBLIC KEY
    // =========================================
    public boolean verify(
            String message,
            String signatureB64) throws Exception {

        if (publicKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa công khai.");
        }

        Signature s =
                Signature.getInstance("SHA256withECDSA");

        // Su dung khoa cong khai de xac minh
        s.initVerify(publicKey);

        // Dua thong diep can kiem tra vao
        s.update(CryptoSupport.utf8(message));

        try {
            return s.verify(
                    CryptoSupport.unb64(signatureB64));

        } catch (java.security.SignatureException ex) {

            // Chu ky sai dinh dang
            return false;
        }
    }

    // =========================================
    // 4. LAY PUBLIC KEY DANG BASE64
    // =========================================
    public String getPublicKeyBase64() {

        return CryptoSupport.b64(
                publicKey.getEncoded());
    }

    // =========================================
    // 5. LAY PRIVATE KEY DANG BASE64
    // =========================================
    public String getPrivateKeyBase64() {

        return CryptoSupport.b64(
                privateKey.getEncoded());
    }

    // =========================================
    // 6. NAP CAP KHOA DA LUU
    // =========================================
    public void loadKeys(
            String publicB64,
            String privateB64) throws Exception {

        KeyFactory kf =
                KeyFactory.getInstance("EC");

        publicKey = kf.generatePublic(
                new X509EncodedKeySpec(
                        CryptoSupport.unb64(publicB64)
                )
        );

        privateKey = privateB64.isBlank()
                ? null
                : kf.generatePrivate(
                        new PKCS8EncodedKeySpec(
                                CryptoSupport.unb64(privateB64)
                        )
                );
    }
}

