/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_03;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


/**
 *
 * @author LENOVO
 */
public class frm_ECC extends javax.swing.JFrame {
        // Đối tượng thực hiện thuật toán ECC
    private final ECCCipher ecc = new ECCCipher();

    // Các ô văn bản
    private JTextArea txt_public;
    private JTextArea txt_private;
    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;

    // Các nút chức năng
    private JButton btn_generate;
    private JButton btn_savekeys;
    private JButton btn_loadkeys;
    private JButton btn_encrypt;
    private JButton btn_decrypt;

    // Nhãn trạng thái
    private JLabel lbl_status;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frm_ECC.class.getName());

    /**
     * Creates new form frm_ECC
     */
    public frm_ECC() {
            initComponents();
        taoGiaoDienECC();
        setLocationRelativeTo(null);
    }
    
    
    // ==========================================
    // 1. TẠO GIAO DIỆN ECC
    // ==========================================
    private void taoGiaoDienECC() {

        setTitle("ECC Cipher");

        setDefaultCloseOperation(
                javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        setSize(850, 740);
        setMinimumSize(new Dimension(700, 600));

        JPanel root = new JPanel(
                new BorderLayout(10, 10));

        root.setBorder(
                BorderFactory.createEmptyBorder(
                        18, 20, 18, 20));

        setContentPane(root);

        // Tiêu đề
        JLabel title = new JLabel(
                "MẬT MÃ ĐƯỜNG CONG ELLIPTIC (ECC - secp256r1)");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 20));

        root.add(title, BorderLayout.NORTH);

        // Panel nội dung
        JPanel content = new JPanel();

        content.setLayout(
                new BoxLayout(content, BoxLayout.Y_AXIS));

        JScrollPane mainScroll = new JScrollPane(content);
        mainScroll.setBorder(null);

        root.add(mainScroll, BorderLayout.CENTER);

        // ---------------------------
        // PUBLIC KEY
        // ---------------------------
        content.add(new JLabel("Public key:"));
        content.add(Box.createVerticalStrut(5));

        txt_public = taoOText(2, false);

        content.add(taoThanhCuon(txt_public, 65));
        content.add(Box.createVerticalStrut(12));

        // ---------------------------
        // PRIVATE KEY
        // ---------------------------
        content.add(new JLabel("Private key:"));
        content.add(Box.createVerticalStrut(5));

        txt_private = taoOText(2, false);

        content.add(taoThanhCuon(txt_private, 65));
        content.add(Box.createVerticalStrut(12));

        // ---------------------------
        // NÚT XỬ LÝ KHÓA
        // ---------------------------
        JPanel keyButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        keyButtons.setAlignmentX(LEFT_ALIGNMENT);
        keyButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 42));

        btn_generate = new JButton("Generate Keys");
        btn_savekeys = new JButton("Save Keys");
        btn_loadkeys = new JButton("Load Keys");

        keyButtons.add(btn_generate);
        keyButtons.add(btn_savekeys);
        keyButtons.add(btn_loadkeys);

        content.add(keyButtons);
        content.add(Box.createVerticalStrut(14));

        // ---------------------------
        // PLAINTEXT
        // ---------------------------
        content.add(new JLabel("Plaintext:"));
        content.add(Box.createVerticalStrut(5));

        txt_plaintext = taoOText(3, true);

        content.add(taoThanhCuon(txt_plaintext, 85));
        content.add(Box.createVerticalStrut(14));

        // ---------------------------
        // CIPHERTEXT
        // ---------------------------
        content.add(new JLabel("Ciphertext:"));
        content.add(Box.createVerticalStrut(5));

        txt_ciphertext = taoOText(5, true);

        content.add(taoThanhCuon(txt_ciphertext, 130));
        content.add(Box.createVerticalStrut(12));

        // ---------------------------
        // NÚT ENCRYPT / DECRYPT
        // ---------------------------
        JPanel actionButtons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        actionButtons.setAlignmentX(LEFT_ALIGNMENT);
        actionButtons.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 42));

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");

        actionButtons.add(btn_encrypt);
        actionButtons.add(btn_decrypt);

        content.add(actionButtons);

        // ---------------------------
        // TRẠNG THÁI
        // ---------------------------
        lbl_status = new JLabel(
                "Bấm Generate Keys hoặc Load Keys.");

        lbl_status.setBorder(
                BorderFactory.createEmptyBorder(8, 0, 2, 0));

        root.add(lbl_status, BorderLayout.SOUTH);

        // ---------------------------
        // GẮN SỰ KIỆN NÚT
        // ---------------------------
        btn_generate.addActionListener(
                e -> xuLyTaoKhoa());

        btn_savekeys.addActionListener(
                e -> xuLyLuuKhoa());

        btn_loadkeys.addActionListener(
                e -> xuLyNapKhoa());

        btn_encrypt.addActionListener(
                e -> xuLyMaHoa());

        btn_decrypt.addActionListener(
                e -> xuLyGiaiMa());
    }

    // ==========================================
    // 2. HÀM TẠO Ô VĂN BẢN
    // ==========================================
    private JTextArea taoOText(
            int rows, boolean editable) {

        JTextArea area = new JTextArea(rows, 55);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(editable);

        area.setFont(
                new Font("Consolas", Font.PLAIN, 13));

        return area;
    }

    // ==========================================
    // 3. HÀM TẠO THANH CUỘN
    // ==========================================
    private JScrollPane taoThanhCuon(
            JTextArea area, int height) {

        JScrollPane scroll = new JScrollPane(area);

        scroll.setAlignmentX(LEFT_ALIGNMENT);

        scroll.setPreferredSize(
                new Dimension(700, height));

        scroll.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, height));

        return scroll;
    }

    // ==========================================
    // 4. HIỂN THỊ CẶP KHÓA
    // ==========================================
    private void showKeys() {

        txt_public.setText(
                ecc.getPublicKeyBase64());

        txt_private.setText(
                ecc.getPrivateKeyBase64());

        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    // ==========================================
    // 5. GENERATE KEYS
    // ==========================================
    private void xuLyTaoKhoa() {

        try {
            ecc.generateKeys();

            showKeys();

            lbl_status.setText(
                    "Đã tạo cặp khóa ECC mới.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Không tạo được khóa: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 6. SAVE KEYS
    // ==========================================
    private void xuLyLuuKhoa() {

        if (txt_public.getText().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, "Chưa có khóa để lưu.");
            return;
        }

        String content = CryptoSupport.toKeyFile(
                txt_public.getText(),
                txt_private.getText()
        );

        String path = FileTextIO.saveString(
                this, content, "ecc_keys.txt");

        if (path != null) {
            lbl_status.setText(
                    "Đã lưu khóa vào: " + path);
        }
    }

    // ==========================================
    // 7. LOAD KEYS
    // ==========================================
    private void xuLyNapKhoa() {

        String content = FileTextIO.openString(this);

        if (content == null) {
            return;
        }

        try {
            String[] keys =
                    CryptoSupport.fromKeyFile(content);

            ecc.loadKeys(keys[0], keys[1]);

            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);

            lbl_status.setText(
                    "Đã nạp khóa từ tệp.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Tệp khóa không hợp lệ: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 8. ENCRYPT
    // ==========================================
    private void xuLyMaHoa() {

        String plaintext =
                txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa.");

            return;
        }

        try {
            String ciphertext =
                    ecc.encrypt(plaintext);

            txt_ciphertext.setText(ciphertext);
            txt_ciphertext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã mã hóa ECC ("
                    + ciphertext.length()
                    + " ký tự Base64).");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại: "
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // 9. DECRYPT
    // ==========================================
    private void xuLyGiaiMa() {

        String ciphertext =
                txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã.");

            return;
        }

        try {
            String plaintext =
                    ecc.decrypt(ciphertext);

            txt_plaintext.setText(plaintext);
            txt_plaintext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã giải mã ECC thành công.");

        } catch (Exception ex) {

            lbl_status.setText(
                    "Giải mã ECC THẤT BẠI "
                    + "(sai khóa hoặc bản mã bị sửa).");

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: "
                    + ex.getMessage(),
                    "Giải mã thất bại",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frm_ECC().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
