/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_03;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 * Bài 3.2 - Mật mã RSA với giao diện Swing.
 * Giao diện được tạo hoàn toàn bằng Java.
 */
public class frm_RSA extends JFrame {

    // Đối tượng xử lý thuật toán RSA
    private final RSACipher rsa = new RSACipher();

    // Các điều khiển trên giao diện
    private JComboBox<String> cbo_bits;

    private JButton btn_generate;
    private JButton btn_encrypt;
    private JButton btn_decrypt;

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;

    private JLabel lbl_keyinfo;
    private JLabel lbl_status;

    // Constructor
    public frm_RSA() {
        initComponents();
        setLocationRelativeTo(null);
        taoGiaoDienRSA();
    }

    // ==================================================
    // 1. TẠO GIAO DIỆN
    // ==================================================
    private void taoGiaoDienRSA() {

        setTitle("RSA Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(750, 570);
        setMinimumSize(new Dimension(650, 500));

        JPanel root = new JPanel(
                new BorderLayout(10, 12));

        root.setBorder(
                BorderFactory.createEmptyBorder(
                        18, 22, 18, 22));

        setContentPane(root);

        // Tiêu đề
        JLabel title = new JLabel(
                "MẬT MÃ RSA (OAEP - SHA-256)");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 20));

        root.add(title, BorderLayout.NORTH);

        // Panel nội dung
        JPanel center = new JPanel();

        center.setLayout(
                new BoxLayout(center, BoxLayout.Y_AXIS));

        root.add(center, BorderLayout.CENTER);

        // Chọn kích thước khóa
        JPanel keyRow = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 0));

        keyRow.setAlignmentX(LEFT_ALIGNMENT);
        keyRow.add(new JLabel("Key size:"));

        cbo_bits = new JComboBox<>(
                new String[]{"2048", "3072"});

        keyRow.add(cbo_bits);

        // Nút Generate Keys
        btn_generate = new JButton("Generate Keys");
        keyRow.add(btn_generate);

        center.add(keyRow);
        center.add(Box.createVerticalStrut(6));

        // Nhãn thông tin khóa
        lbl_keyinfo = new JLabel("Chưa có khóa.");
        lbl_keyinfo.setAlignmentX(LEFT_ALIGNMENT);

        center.add(lbl_keyinfo);
        center.add(Box.createVerticalStrut(16));

        // Nhãn Plaintext
        JLabel plainLabel = new JLabel("Plaintext:");
        plainLabel.setAlignmentX(LEFT_ALIGNMENT);

        center.add(plainLabel);
        center.add(Box.createVerticalStrut(5));

        // Ô nhập bản rõ
        txt_plaintext = new JTextArea(3, 55);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);

        JScrollPane plainScroll =
                new JScrollPane(txt_plaintext);

        plainScroll.setAlignmentX(LEFT_ALIGNMENT);
        plainScroll.setPreferredSize(
                new Dimension(600, 85));

        center.add(plainScroll);
        center.add(Box.createVerticalStrut(14));

        // Nhãn Ciphertext
        JLabel cipherLabel = new JLabel("Ciphertext:");
        cipherLabel.setAlignmentX(LEFT_ALIGNMENT);

        center.add(cipherLabel);
        center.add(Box.createVerticalStrut(5));

        // Ô hiển thị bản mã
        txt_ciphertext = new JTextArea(6, 55);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);

        JScrollPane cipherScroll =
                new JScrollPane(txt_ciphertext);

        cipherScroll.setAlignmentX(LEFT_ALIGNMENT);
        cipherScroll.setPreferredSize(
                new Dimension(600, 170));

        center.add(cipherScroll);
        center.add(Box.createVerticalGlue());

        // Panel phía dưới
        JPanel bottom = new JPanel();

        bottom.setLayout(
                new BoxLayout(bottom, BoxLayout.Y_AXIS));

        JPanel buttons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 4));

        buttons.setAlignmentX(LEFT_ALIGNMENT);

        // Hai nút Encrypt và Decrypt
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");

        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);

        bottom.add(buttons);

        // Nhãn trạng thái
        lbl_status = new JLabel(
                "Bấm Generate Keys để tạo cặp khóa.");

        lbl_status.setAlignmentX(LEFT_ALIGNMENT);

        bottom.add(lbl_status);
        root.add(bottom, BorderLayout.SOUTH);

        // Gắn sự kiện cho từng nút
        btn_generate.addActionListener(
                e -> btn_generateActionPerformed());

        btn_encrypt.addActionListener(
                e -> btn_encryptActionPerformed());

        btn_decrypt.addActionListener(
                e -> btn_decryptActionPerformed());
    }

    // ==================================================
    // 2. NÚT GENERATE KEYS
    // ==================================================
    private void btn_generateActionPerformed() {

        int bits = Integer.parseInt(
                (String) cbo_bits.getSelectedItem());

        try {
            long start = System.currentTimeMillis();

            rsa.generateKeys(bits);

            long ms = System.currentTimeMillis() - start;

            lbl_keyinfo.setText(
                    "RSA-" + bits
                    + ": tạo khóa " + ms
                    + " ms, tối đa "
                    + rsa.maxPlaintextBytes() + " byte");

            lbl_status.setText(
                    "Đã tạo cặp khóa. Khóa công khai dùng để mã hóa, khóa riêng để giải mã.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==================================================
    // 3. NÚT ENCRYPT
    // ==================================================
    private void btn_encryptActionPerformed() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }

        try {
            String ciphertext = rsa.encrypt(plaintext);

            txt_ciphertext.setText(ciphertext);
            txt_ciphertext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã mã hóa RSA ("
                    + ciphertext.length()
                    + " ký tự Base64).");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==================================================
    // 4. NÚT DECRYPT
    // ==================================================
    private void btn_decryptActionPerformed() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }

        try {
            String plaintext = rsa.decrypt(ciphertext);

            txt_plaintext.setText(plaintext);
            txt_plaintext.setCaretPosition(0);

            lbl_status.setText(
                    "Đã giải mã RSA thành công.");

        } catch (Exception ex) {

            lbl_status.setText(
                    "Giải mã RSA THẤT BẠI (sai khóa hoặc bản mã bị sửa).");

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: sai khóa riêng hoặc bản mã bị sửa.\n"
                    + ex,
                    "Giải mã thất bại",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    // ==================================================
    // 5. HÀM MAIN - CHẠY GIAO DIỆN
    // ==================================================
    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () -> new frm_RSA().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
