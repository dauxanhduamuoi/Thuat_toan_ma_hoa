/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;

/**
 * He ma lai RSA + AES.
 *
 * AES-256-GCM ma hoa van ban dai.
 * RSA-OAEP ma hoa khoa AES 32 byte.
 *
 * Ban ma = Base64(
 *     khoa AES da ma hoa RSA 256 byte
 *     + nonce 12 byte
 *     + du lieu AES-GCM
 * )
 */
public final class RSA_AES_Cipher {

    private static final String RSA =
            "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";

    private static final OAEPParameterSpec OAEP =
            new OAEPParameterSpec(
                    "SHA-256",
                    "MGF1",
                    MGF1ParameterSpec.SHA256,
                    PSource.PSpecified.DEFAULT
            );

    // RSA-2048 tao ban ma khoa AES dai 256 byte
    private static final int WRAPPED = 256;

    private PublicKey publicKey;
    private PrivateKey privateKey;

    // =========================================
    // 1. TAO CAP KHOA RSA
    // =========================================
    public void generateKeys() throws Exception {

        KeyPairGenerator gen =
                KeyPairGenerator.getInstance("RSA");

        gen.initialize(2048);

        KeyPair p = gen.generateKeyPair();

        publicKey = p.getPublic();
        privateKey = p.getPrivate();
    }

    // =========================================
    // 2. MA HOA RSA + AES
    // =========================================
    public String encrypt(String plaintext) throws Exception {

        if (publicKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa: bấm Generate Keys hoặc Load Keys.");
        }

        // Buoc 1: Sinh khoa AES 256 bit (32 byte)
        byte[] aesKey = CryptoSupport.randomBytes(32);

        // Sinh nonce 12 byte
        byte[] nonce = CryptoSupport.randomBytes(12);

        // Buoc 2: AES-GCM ma hoa van ban
        byte[] data = CryptoSupport.gcmEncrypt(
                aesKey,
                nonce,
                CryptoSupport.utf8(plaintext)
        );

        // Buoc 3: RSA ma hoa khoa AES
        Cipher rsa = Cipher.getInstance(RSA);

        rsa.init(
                Cipher.ENCRYPT_MODE,
                publicKey,
                OAEP
        );

        byte[] wrapped = rsa.doFinal(aesKey);

        // Buoc 4: Ghep va chuyen sang Base64
        return CryptoSupport.b64(
                CryptoSupport.concat(
                        wrapped,
                        nonce,
                        data
                )
        );
    }

    // =========================================
    // 3. GIAI MA RSA + AES
    // =========================================
    public String decrypt(String ciphertext) throws Exception {

        if (privateKey == null) {
            throw new IllegalStateException(
                    "Chưa có khóa riêng.");
        }

        // Chuyen chuoi Base64 thanh byte
        byte[] all = CryptoSupport.unb64(ciphertext);

        // Tach khoa AES da ma hoa RSA
        byte[] wrapped = CryptoSupport.slice(
                all, 0, WRAPPED);

        // Tach nonce
        byte[] nonce = CryptoSupport.slice(
                all, WRAPPED, WRAPPED + 12);

        // Tach du lieu AES-GCM
        byte[] data = CryptoSupport.slice(
                all, WRAPPED + 12, all.length);

        // Buoc 1: RSA giai ma khoa AES
        Cipher rsa = Cipher.getInstance(RSA);

        rsa.init(
                Cipher.DECRYPT_MODE,
                privateKey,
                OAEP
        );

        byte[] aesKey = rsa.doFinal(wrapped);

        // Buoc 2: AES-GCM giai ma van ban
        return CryptoSupport.text(
                CryptoSupport.gcmDecrypt(
                        aesKey,
                        nonce,
                        data
                )
        );
    }

    // =========================================
    // 4. LAY PUBLIC KEY
    // =========================================
    public String getPublicKeyBase64() {

        return CryptoSupport.b64(
                publicKey.getEncoded());
    }

    // =========================================
    // 5. LAY PRIVATE KEY
    // =========================================
    public String getPrivateKeyBase64() {

        return CryptoSupport.b64(
                privateKey.getEncoded());
    }

    // =========================================
    // 6. NAP LAI CAP KHOA
    // =========================================
    public void loadKeys(
            String publicB64,
            String privateB64) throws Exception {

        KeyFactory kf =
                KeyFactory.getInstance("RSA");

        publicKey = kf.generatePublic(
                new X509EncodedKeySpec(
                        CryptoSupport.unb64(publicB64)
                )
        );

        privateKey = privateB64.isBlank()
                ? null
                : kf.generatePrivate(
                        new PKCS8EncodedKeySpec(
                                CryptoSupport.unb64(privateB64)
                        )
                );
    }
}

