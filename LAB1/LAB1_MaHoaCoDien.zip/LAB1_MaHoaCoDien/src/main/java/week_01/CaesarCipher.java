/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package week_01;

/**
 * Thuật toán mã hóa Caesar.
 */
public final class CaesarCipher {

    private CaesarCipher() {
    }

    // Mã hóa
    public static String encrypt(String text, int key) {
        return transform(text, key);
    }

    // Giải mã
    public static String decrypt(String text, int key) {
        return transform(text, -key);
    }

    // Xử lý dịch chuyển ký tự
    private static String transform(String text, int key) {

        StringBuilder result = new StringBuilder();
        int shift = Math.floorMod(key, 26);

        for (char c : text.toCharArray()) {

            char base;

            if (c >= 'A' && c <= 'Z') {
                base = 'A';
            } else if (c >= 'a' && c <= 'z') {
                base = 'a';
            } else {
                result.append(c);
                continue;
            }

            int original = c - base;
            int encoded = Math.floorMod(original + shift, 26);

            result.append((char) (base + encoded));
        }

        return result.toString();
    }
}

