/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_01;

import java.awt.*;
import javax.swing.*;

/**
 * LAB 1 - Giao diện Playfair Cipher.
 * Bố cục viết bằng Java; NetBeans initComponents() giữ đúng MỘT lần.
 * Phần xử lý thuật toán nằm ở lớp PlayfairCipher, không viết lại tại đây.
 */
public class frm_Playfair extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(frm_Playfair.class.getName());

    public frm_Playfair() {
        initComponents();
        taoGiaoDien();
    }

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JLabel lbl_status;
    private JTextArea txt_matrix;
    private JButton btn_matrix;

    private void taoGiaoDien() {
        setTitle("Playfair Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(10, 15));
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        root.setBackground(new Color(245, 248, 250));

        JLabel title = new JLabel("MẬT MÃ PLAYFAIR");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 7, 7, 7);
        g.fill = GridBagConstraints.HORIZONTAL;

        // Bản rõ (Plaintext)
        g.gridx = 0;
        g.gridy = 0;
        g.weightx = 0;
        form.add(new JLabel("Plaintext:"), g);

        txt_plaintext = new JTextArea(4, 40);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_plaintext), g);

        // Khóa (Key)
        g.gridx = 0;
        g.gridy = 1;
        g.weightx = 0;
        form.add(new JLabel("Key:"), g);

        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        keyPanel.setOpaque(false);
        txt_key = new JTextField("KEYWORD", 12);
        keyPanel.add(txt_key);
        keyPanel.add(new JLabel("Chỉ gồm chữ A-Z, ví dụ KEYWORD"));
        g.gridx = 1;
        g.weightx = 1;
        form.add(keyPanel, g);

        // Ma trận khóa 5x5 - chỉ riêng Playfair mới có.
        g.gridx = 0;
        g.gridy = 2;
        g.weightx = 0;
        form.add(new JLabel("Key Matrix:"), g);

        txt_matrix = new JTextArea(5, 10);
        txt_matrix.setEditable(false);
        txt_matrix.setLineWrap(false);
        txt_matrix.setFont(new Font("Monospaced", Font.BOLD, 14));
        txt_matrix.setBackground(new Color(250, 250, 250));
        btn_matrix = new JButton("Generate Key Matrix");

        JPanel matrixPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        matrixPanel.setOpaque(false);
        JScrollPane matrixScroll = new JScrollPane(txt_matrix);
        matrixScroll.setPreferredSize(new Dimension(190, 110));
        matrixPanel.add(matrixScroll);
        matrixPanel.add(btn_matrix);

        g.gridx = 1;
        g.weightx = 1;
        form.add(matrixPanel, g);

        // Bản mã (Ciphertext)
        g.gridx = 0;
        g.gridy = 3;
        g.weightx = 0;
        form.add(new JLabel("Ciphertext:"), g);

        txt_ciphertext = new JTextArea(4, 40);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_ciphertext), g);

        root.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttons.setOpaque(false);
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");
        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);
        buttons.add(btn_open);
        buttons.add(btn_save);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setForeground(new Color(90, 100, 110));

        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);
        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
        setSize(780, 620);
        setLocationRelativeTo(null);

        btn_encrypt.addActionListener(e -> xuLyMaHoa());
        btn_decrypt.addActionListener(e -> xuLyGiaiMa());
        btn_open.addActionListener(e -> xuLyMoFile());
        btn_save.addActionListener(e -> xuLyLuuFile());
        btn_matrix.addActionListener(e -> xuLyMaTran());
    }

    private void xuLyMaHoa() {
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }

        try {
            String key = txt_key.getText().trim();
            txt_ciphertext.setText(PlayfairCipher.encrypt(plaintext, key));
            lbl_status.setText("Đã mã hóa Playfair (bỏ dấu cách, J -> I, chèn X).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyGiaiMa() {
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }

        try {
            String key = txt_key.getText().trim();
            txt_plaintext.setText(PlayfairCipher.decrypt(ciphertext, key));
            lbl_status.setText("Đã giải mã Playfair (còn ký tự đệm X).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyMoFile() {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    private void xuLyLuuFile() {
        String path = FileTextIO.saveText(this, txt_ciphertext,
                "playfair_ciphertext.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    // Tạo ma trận 5x5 từ khóa KEYWORD (I/J chung một ô).
    private void xuLyMaTran() {
        try {
            txt_matrix.setText(PlayfairCipher.getKeyMatrix(txt_key.getText()));
            txt_matrix.setCaretPosition(0);
            lbl_status.setText("Đã tạo ma trận khóa 5x5 (I và J dùng chung ô).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Do not edit this method manually: it belongs to NetBeans GUI Builder.
     */
    



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Playfair().setVisible(true));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
