/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_01;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author LENOVO
 */
public class frm_Caesar extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frm_Caesar.class.getName());

    /**
     * Creates new form frm_Caesar
     */
    public frm_Caesar() {
        initComponents();
        taoGiaoDien();
    }
    
    // Các thành phần của giao diện
    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;

    private JLabel lbl_status;

    private void taoGiaoDien() {
        setTitle("Caesar Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Khung giao diện chính
        JPanel root = new JPanel(new BorderLayout(10, 15));
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        root.setBackground(new Color(245, 248, 250));

        // Tiêu đề
        JLabel title = new JLabel("MẬT MÃ CAESAR");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        // Khu vực nhập liệu
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 7, 7, 7);
        g.fill = GridBagConstraints.HORIZONTAL;

        // Plaintext
        g.gridx = 0;
        g.gridy = 0;
        form.add(new JLabel("Plaintext:"), g);

        txt_plaintext = new JTextArea(4, 40);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_plaintext), g);

        // Key
        g.gridx = 0;
        g.gridy = 1;
        g.weightx = 0;
        form.add(new JLabel("Key:"), g);

        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        keyPanel.setOpaque(false);

        txt_key = new JTextField("3", 12);
        keyPanel.add(txt_key);
        keyPanel.add(new JLabel("Số nguyên, ví dụ 3"));

        g.gridx = 1;
        g.weightx = 1;
        form.add(keyPanel, g);

        // Ciphertext
        g.gridx = 0;
        g.gridy = 2;
        g.weightx = 0;
        form.add(new JLabel("Ciphertext:"), g);

        txt_ciphertext = new JTextArea(4, 40);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_ciphertext), g);

        root.add(form, BorderLayout.CENTER);

        // Các nút chức năng
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttons.setOpaque(false);

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");

        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);
        buttons.add(btn_open);
        buttons.add(btn_save);

        // Trạng thái chương trình
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setForeground(new Color(90, 100, 110));

        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);
        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);

        root.add(footer, BorderLayout.SOUTH);

        // Hiển thị cửa sổ
        setContentPane(root);
        setSize(720, 440);
        setLocationRelativeTo(null);
        
        // Gắn sự kiện cho nút Encrypt
        btn_encrypt.addActionListener(e -> xuLyMaHoa());

        // Gắn sự kiện cho nút Decrypt
        btn_decrypt.addActionListener(e -> xuLyGiaiMa());
        
        // Nút mở file bản mã
        btn_open.addActionListener(e -> xuLyMoFile());

        // Nút lưu file bản mã
        btn_save.addActionListener(e -> xuLyLuuFile());
    }
    
    
    // Xử lý nút Open Ciphertext File
    private void xuLyMoFile() {

        String path = FileTextIO.openText(this, txt_ciphertext);

        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    // Xử lý nút Save Ciphertext File
    private void xuLyLuuFile() {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "caesar_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    
    // Xử lý khi nhấn nút Encrypt
    private void xuLyMaHoa() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            int key = Integer.parseInt(txt_key.getText().trim());

            String result = CaesarCipher.encrypt(plaintext, key);

            txt_ciphertext.setText(result);

            lbl_status.setText("Đã mã hóa với khóa k = " + key + ".");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Khóa Caesar phải là số nguyên, ví dụ 3.",
                "Khóa không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Xử lý khi nhấn nút Decrypt
    private void xuLyGiaiMa() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            int key = Integer.parseInt(txt_key.getText().trim());

            String result = CaesarCipher.decrypt(ciphertext, key);

            txt_plaintext.setText(result);

            lbl_status.setText("Đã giải mã với khóa k = " + key + ".");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Khóa Caesar phải là số nguyên, ví dụ 3.",
                "Khóa không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frm_Caesar().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
