/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week_02;

import java.util.Arrays;
import javax.crypto.AEADBadTagException;

/** Lớp kiểm thử tạm thời: không nằm trong tài liệu gốc. */
public class TestAES {
    public static void main(String[] args) throws Exception {
        String original = "Xin chào Lab 2 - Mã hóa hiện đại!";
        String password = "MatKhauAES@2026";

        String ciphertext = AESCipher.encrypt(original, password);
        String decrypted = AESCipher.decrypt(ciphertext, password);
        System.out.println("Plaintext: " + original);
        System.out.println("Ciphertext (Base64): " + ciphertext);
        System.out.println("Decrypted: " + decrypted);
        System.out.println("TEST 1 - decrypt: " + (original.equals(decrypted) ? "PASS" : "FAIL"));

        String ciphertext2 = AESCipher.encrypt(original, password);
        System.out.println("TEST 2 - salt/nonce ngẫu nhiên: "
                + (!ciphertext.equals(ciphertext2) ? "PASS" : "FAIL"));

        byte[] tampered = CipherUtil.fromB64(ciphertext);
        tampered[tampered.length - 1] ^= 1;
        try {
            AESCipher.decrypt(CipherUtil.b64(tampered), password);
            System.out.println("TEST 3 - chống sửa bản mã: FAIL");
        } catch (AEADBadTagException ex) {
            System.out.println("TEST 3 - chống sửa bản mã: PASS");
        }

        try {
            AESCipher.decrypt(ciphertext, "SaiMatKhauAES2026");
            System.out.println("TEST 4 - sai mật khẩu: FAIL");
        } catch (AEADBadTagException ex) {
            System.out.println("TEST 4 - sai mật khẩu: PASS");
        }
    }
}
