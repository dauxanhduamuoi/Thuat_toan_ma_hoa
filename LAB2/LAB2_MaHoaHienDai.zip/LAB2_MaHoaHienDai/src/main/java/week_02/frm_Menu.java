package week_02;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * LAB 2 - Menu chinh theo Bang 2.11 (trang 46-48).
 * Giao dien tao hoan toan bang Java Swing, khong dung GUI Builder.
 */
public class frm_Menu extends JFrame {

    private JButton btn_des;
    private JButton btn_tripledes;
    private JButton btn_aes;
    private JButton btn_rc4;
    private JButton btn_twofish;
    private JButton btn_aesctr;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_Menu() {
        taoGiaoDien();
    }

    private JButton taoNut(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        button.setFocusPainted(false);
        button.setMargin(new Insets(10, 15, 10, 15));
        button.setPreferredSize(new Dimension(220, 46));
        return button;
    }

    private void taoGiaoDien() {
        setTitle("LAB 2 - Mã hóa đối xứng hiện đại");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBackground(new Color(245, 248, 250));
        root.setBorder(BorderFactory.createEmptyBorder(24, 30, 24, 30));

        JPanel header = new JPanel(new BorderLayout(0, 10));
        header.setOpaque(false);
        JLabel title = new JLabel("LAB 2 - MÃ HÓA ĐỐI XỨNG HIỆN ĐẠI");
        title.setFont(new Font("Segoe UI", Font.BOLD, 23));
        title.setForeground(new Color(30, 55, 80));
        header.add(title, BorderLayout.NORTH);
        JLabel subtitle = new JLabel("Chọn một bài để mở form tương ứng:");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        header.add(subtitle, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new GridLayout(4, 2, 16, 16));
        buttons.setOpaque(false);
        btn_des = taoNut("2.1 DES");
        btn_tripledes = taoNut("2.2 TripleDES");
        btn_aes = taoNut("2.3 AES + Login");
        btn_rc4 = taoNut("2.4 RC4");
        btn_twofish = taoNut("2.5 Twofish");
        btn_aesctr = taoNut("2.6 Nâng cao - AES-CTR");
        btn_sql = taoNut("Kết nối SQL Server");
        btn_history = taoNut("Xem lịch sử");

        buttons.add(btn_des);
        buttons.add(btn_tripledes);
        buttons.add(btn_aes);
        buttons.add(btn_rc4);
        buttons.add(btn_twofish);
        buttons.add(btn_aesctr);
        buttons.add(btn_sql);
        buttons.add(btn_history);
        root.add(buttons, BorderLayout.CENTER);

        JLabel pythonNote = new JLabel(
            "Bài nâng cao 02 (AES-CBC) viết bằng Python: chạy tệp aes_cbc_gui.py.",
            SwingConstants.CENTER
        );
        pythonNote.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        pythonNote.setForeground(new Color(90, 100, 110));
        root.add(pythonNote, BorderLayout.SOUTH);

        // Su kien nut: mo cac form da tao o nhung bai truoc.
        btn_des.addActionListener(e -> new frm_DES().setVisible(true));
        btn_tripledes.addActionListener(e -> new frm_TripleDES().setVisible(true));
        btn_aes.addActionListener(e -> new frm_AES().setVisible(true));
        btn_rc4.addActionListener(e -> new frm_RC4().setVisible(true));
        btn_twofish.addActionListener(e -> new frm_Twofish().setVisible(true));
        btn_aesctr.addActionListener(e -> new frm_AES_CTR().setVisible(true));
        btn_sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));

        setContentPane(root);
        setSize(740, 500);
        setMinimumSize(new Dimension(660, 460));
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // Neu khong co Nimbus, van dung giao dien mac dinh.
        }
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
