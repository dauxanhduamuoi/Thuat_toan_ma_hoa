package week_02;

import java.awt.*;
import javax.swing.*;

/**
 * LAB 2 - Bài nâng cao 01: giao diện AES-256-CTR theo bảng 2.10.
 * Java Class tạo Swing bằng code; không có initComponents().
 */
public class frm_AES_CTR extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;
    private JTextField txt_nonce;

    private JButton btn_genkey;
    private JButton btn_gennonce;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_save;
    private JButton btn_open;
    private JLabel lbl_status;

    public frm_AES_CTR() {
        taoGiaoDien();
    }

    private void taoGiaoDien() {
        setTitle("AES-CTR Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(12, 15));
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        root.setBackground(new Color(245, 248, 250));

        JLabel title = new JLabel("BÀI NÂNG CAO 01 - AES-256 CHẾ ĐỘ CTR");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 7, 8, 7);
        g.fill = GridBagConstraints.HORIZONTAL;

        // Plaintext
        g.gridx = 0;
        g.gridy = 0;
        g.weightx = 0;
        form.add(new JLabel("Plaintext:"), g);

        txt_plaintext = new JTextArea(3, 50);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_plaintext), g);

        // Key: Base64 của 32 byte, không phải mật khẩu gõ tay
        g.gridx = 0;
        g.gridy = 1;
        g.weightx = 0;
        form.add(new JLabel("Key (Base64):"), g);

        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        keyPanel.setOpaque(false);
        txt_key = new JTextField("", 42);
        txt_key.setFont(new Font("Consolas", Font.PLAIN, 13));
        btn_genkey = new JButton("Generate Key");
        keyPanel.add(txt_key);
        keyPanel.add(btn_genkey);
        g.gridx = 1;
        g.weightx = 1;
        form.add(keyPanel, g);

        // Nonce: Base64 của 12 byte
        g.gridx = 0;
        g.gridy = 2;
        g.weightx = 0;
        form.add(new JLabel("Nonce (Base64):"), g);

        JPanel noncePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        noncePanel.setOpaque(false);
        txt_nonce = new JTextField("", 42);
        txt_nonce.setFont(new Font("Consolas", Font.PLAIN, 13));
        btn_gennonce = new JButton("Generate Nonce");
        noncePanel.add(txt_nonce);
        noncePanel.add(btn_gennonce);
        g.gridx = 1;
        g.weightx = 1;
        form.add(noncePanel, g);

        // Ciphertext
        g.gridx = 0;
        g.gridy = 3;
        g.weightx = 0;
        form.add(new JLabel("Ciphertext:"), g);

        txt_ciphertext = new JTextArea(3, 50);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_ciphertext), g);
        root.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        buttons.setOpaque(false);
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_save = new JButton("Save File");
        btn_open = new JButton("Open File");
        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);
        buttons.add(btn_save);
        buttons.add(btn_open);

        lbl_status = new JLabel("Sẵn sàng. Bấm Generate Key và Generate Nonce trước khi mã hóa.");
        lbl_status.setForeground(new Color(85, 95, 108));
        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);
        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
        setMinimumSize(new Dimension(900, 495));
        pack();
        setLocationRelativeTo(null);

        btn_genkey.addActionListener(e -> xuLyTaoKey());
        btn_gennonce.addActionListener(e -> xuLyTaoNonce());
        btn_encrypt.addActionListener(e -> xuLyMaHoa());
        btn_decrypt.addActionListener(e -> xuLyGiaiMa());
        btn_save.addActionListener(e -> xuLyLuuFile());
        btn_open.addActionListener(e -> xuLyMoFile());
    }

    private void xuLyTaoKey() {
        txt_key.setText(AESCTRCipher.newKey());
        lbl_status.setText("Đã tạo khóa ngẫu nhiên 256 bit. Hãy giữ lại Key để giải mã.");
    }

    private void xuLyTaoNonce() {
        txt_nonce.setText(AESCTRCipher.newNonce());
        lbl_status.setText("Đã tạo nonce ngẫu nhiên 96 bit. Mỗi lần mã hóa nên tạo nonce mới.");
    }

    private void xuLyMaHoa() {
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String ciphertext = AESCTRCipher.encrypt(
                    plaintext, txt_key.getText(), txt_nonce.getText());
            txt_ciphertext.setText(ciphertext);
            lbl_status.setText("<html>Đã mã hóa AES-CTR. "
                    + HistoryDao.tryInsert("AES-CTR", "ENCRYPT", null,
                            plaintext.length(), ciphertext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyGiaiMa() {
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String plaintext = AESCTRCipher.decrypt(
                    ciphertext, txt_key.getText(), txt_nonce.getText());
            txt_plaintext.setText(plaintext);
            lbl_status.setText("<html>Đã giải mã AES-CTR. "
                    + HistoryDao.tryInsert("AES-CTR", "DECRYPT", null,
                            ciphertext.length(), plaintext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n"
                    + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyLuuFile() {
        if (txt_ciphertext.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Chưa có bản mã để lưu.");
            return;
        }
        String content = AESCTRCipher.toFile(txt_nonce.getText(), txt_ciphertext.getText());
        String path = FileTextIO.saveString(this, content, "aes_ctr_ciphertext.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu nonce + bản mã (không lưu Key) vào: " + path);
        }
    }

    private void xuLyMoFile() {
        String content = FileTextIO.openString(this);
        if (content == null) {
            return;
        }
        try {
            String[] parts = AESCTRCipher.fromFile(content);
            txt_nonce.setText(parts[0]);
            txt_ciphertext.setText(parts[1]);
            lbl_status.setText("Đã mở tệp. Nhập đúng Key rồi bấm Decrypt.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Tệp không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_AES_CTR().setVisible(true));
    }
}
