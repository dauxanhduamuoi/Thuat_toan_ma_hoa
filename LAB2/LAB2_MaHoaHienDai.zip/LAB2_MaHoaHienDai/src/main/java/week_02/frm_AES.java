package week_02;

import java.awt.*;
import java.sql.SQLException;
import java.util.Arrays;
import javax.swing.*;

/** Bài 2.3 - AES-GCM - Đăng ký/Đăng nhập (SQL Server). Giao diện dựng bằng code. */
public class frm_AES extends JFrame {
    /** null = chưa Login thành công. */
    private String currentUser = null;

    private JTextField txt_username;
    private JPasswordField txt_password;
    private JTextField txt_ticket;
    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JButton btn_sql, btn_register, btn_login;
    private JButton btn_encrypt, btn_decrypt, btn_save, btn_open;
    private JLabel lbl_status;

    public frm_AES() {
        taoGiaoDien();
    }

    private void taoGiaoDien() {
        setTitle("AES Cipher - Register / Login");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(12, 14));
        root.setBackground(new Color(245, 248, 250));
        root.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        JLabel title = new JLabel("AES-GCM - ĐĂNG KÝ / ĐĂNG NHẬP (SQL SERVER)");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 7, 6, 7);
        g.fill = GridBagConstraints.HORIZONTAL;

        txt_username = new JTextField("sinhvien01", 25);
        addRow(form, g, 0, "Username:", txt_username);

        txt_password = new JPasswordField(25);
        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        passwordPanel.setOpaque(false);
        passwordPanel.add(txt_password);
        passwordPanel.add(new JLabel("(ít nhất 8 ký tự)"));
        addRow(form, g, 1, "Password:", passwordPanel);

        btn_sql = new JButton("Kết nối SQL Server");
        btn_register = new JButton("Register");
        btn_login = new JButton("Login");
        JPanel authButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        authButtons.setOpaque(false);
        authButtons.add(btn_sql);
        authButtons.add(btn_register);
        authButtons.add(btn_login);
        addRow(form, g, 2, "", authButtons);

        txt_ticket = new JTextField(42);
        txt_ticket.setEditable(false);
        addRow(form, g, 3, "Ticket:", txt_ticket);

        txt_plaintext = new JTextArea(3, 50);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addRow(form, g, 4, "Plaintext:", new JScrollPane(txt_plaintext));

        txt_key = new JTextField(28);
        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        keyPanel.setOpaque(false);
        keyPanel.add(txt_key);
        keyPanel.add(new JLabel("Mật khẩu để tạo khóa AES-256"));
        addRow(form, g, 5, "Key AES:", keyPanel);

        txt_ciphertext = new JTextArea(3, 50);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addRow(form, g, 6, "Ciphertext:", new JScrollPane(txt_ciphertext));

        root.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        buttons.setOpaque(false);
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_save = new JButton("Save File");
        btn_open = new JButton("Open File");
        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);
        buttons.add(btn_save);
        buttons.add(btn_open);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setForeground(new Color(85, 95, 108));
        JPanel footer = new JPanel(new BorderLayout(0, 10));
        footer.setOpaque(false);
        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(new JScrollPane(root,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
        setSize(980, 610);
        setMinimumSize(new Dimension(780, 560));
        setLocationRelativeTo(null);

        btn_sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));
        btn_register.addActionListener(e -> xuLyDangKy());
        btn_login.addActionListener(e -> xuLyDangNhap());
        btn_encrypt.addActionListener(e -> xuLyMaHoa());
        btn_decrypt.addActionListener(e -> xuLyGiaiMa());
        btn_save.addActionListener(e -> xuLyLuuFile());
        btn_open.addActionListener(e -> xuLyMoFile());
    }

    private static void addRow(JPanel form, GridBagConstraints g, int y,
            String label, Component value) {
        g.gridy = y;
        g.gridx = 0;
        g.weightx = 0;
        form.add(new JLabel(label), g);
        g.gridx = 1;
        g.weightx = 1;
        form.add(value, g);
    }

    private void xuLyDangKy() {
        char[] password = txt_password.getPassword();
        try {
            String user = txt_username.getText().trim();
            UserDao.register(user, password);
            HistoryDao.tryInsert("AES", "REGISTER", user, 0, 0);
            lbl_status.setText("Register thành công: " + user + ". Bấm Login để đăng nhập.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi SQL Server: " + ex.getMessage(),
                    "Lỗi SQL Server", JOptionPane.ERROR_MESSAGE);
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private void xuLyDangNhap() {
        char[] password = txt_password.getPassword();
        try {
            String user = txt_username.getText().trim();
            if (UserDao.login(user, password)) {
                currentUser = user;
                txt_ticket.setText(UserDao.newTicket());
                HistoryDao.tryInsert("AES", "LOGIN", user, 0, 0);
                lbl_status.setText("Login thành công: " + user + ". Có thể dùng Encrypt/Decrypt.");
            } else {
                currentUser = null;
                txt_ticket.setText("");
                JOptionPane.showMessageDialog(this, "Sai username hoặc mật khẩu.",
                        "Login thất bại", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            currentUser = null;
            txt_ticket.setText("");
            JOptionPane.showMessageDialog(this, "Lỗi SQL Server: " + ex.getMessage(),
                    "Lỗi SQL Server", JOptionPane.ERROR_MESSAGE);
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private void xuLyMaHoa() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Hãy Login trước khi dùng AES.");
            return;
        }
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String ciphertext = AESCipher.encrypt(plaintext, txt_key.getText());
            txt_ciphertext.setText(ciphertext);
            lbl_status.setText("<html>Đã mã hóa AES. " +
                    HistoryDao.tryInsert("AES", "ENCRYPT", currentUser,
                            plaintext.length(), ciphertext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyGiaiMa() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Hãy Login trước khi dùng AES.");
            return;
        }
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String plaintext = AESCipher.decrypt(ciphertext, txt_key.getText());
            txt_plaintext.setText(plaintext);
            lbl_status.setText("<html>Đã giải mã AES. " +
                    HistoryDao.tryInsert("AES", "DECRYPT", currentUser,
                            ciphertext.length(), plaintext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuLyLuuFile() {
        String path = FileTextIO.saveText(this, txt_ciphertext, "aes_ciphertext.txt");
        if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
    }

    private void xuLyMoFile() {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_AES().setVisible(true));
    }
}
