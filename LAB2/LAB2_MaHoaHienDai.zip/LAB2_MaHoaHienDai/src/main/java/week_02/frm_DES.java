/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package week_02;

import java.awt.*;
import javax.swing.*;

/**
 * LAB 2 - Bai 2.1: Giao dien DES.
 * Tao giao dien truc tiep bang Java Swing.
 */
public class frm_DES extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_save;
    private JButton btn_open;

    private JLabel lbl_status;

    public frm_DES() {
        taoGiaoDien();
    }

    // =====================================
    // 1. THIET KE GIAO DIEN
    // =====================================
    private void taoGiaoDien() {
        setTitle("DES Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(12, 15));
        root.setBorder(
            BorderFactory.createEmptyBorder(20, 24, 20, 24)
        );
        root.setBackground(new Color(245, 248, 250));

        // Tieu de
        JLabel title = new JLabel("MẬT MÃ DES");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 7, 8, 7);
        g.fill = GridBagConstraints.HORIZONTAL;

        // O Plaintext
        g.gridx = 0;
        g.gridy = 0;
        g.weightx = 0;
        form.add(new JLabel("Plaintext:"), g);

        txt_plaintext = new JTextArea(3, 42);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_plaintext), g);

        // O Key
        g.gridx = 0;
        g.gridy = 1;
        g.weightx = 0;
        form.add(new JLabel("Key:"), g);

        JPanel keyPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 10, 0)
        );
        keyPanel.setOpaque(false);

        txt_key = new JTextField("12345678", 22);
        txt_key.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );
        keyPanel.add(txt_key);

        keyPanel.add(
            new JLabel("Đúng 8 ký tự không dấu (8 byte)")
        );

        g.gridx = 1;
        g.weightx = 1;
        form.add(keyPanel, g);

        // O Ciphertext
        g.gridx = 0;
        g.gridy = 2;
        g.weightx = 0;
        form.add(new JLabel("Ciphertext:"), g);

        txt_ciphertext = new JTextArea(3, 42);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        g.gridx = 1;
        g.weightx = 1;
        form.add(new JScrollPane(txt_ciphertext), g);

        root.add(form, BorderLayout.CENTER);

        // Cac nut chuc nang
        JPanel buttons = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 10, 4)
        );
        buttons.setOpaque(false);

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_save = new JButton("Save File");
        btn_open = new JButton("Open File");

        buttons.add(btn_encrypt);
        buttons.add(btn_decrypt);
        buttons.add(btn_save);
        buttons.add(btn_open);

        // Trang thai
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setForeground(new Color(85, 95, 108));

        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);

        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);

        root.add(footer, BorderLayout.SOUTH);

        // Hien thi cua so
        setContentPane(root);
        setMinimumSize(new Dimension(740, 420));
        pack();
        setLocationRelativeTo(null);

        // Gan su kien cho cac nut
        btn_encrypt.addActionListener(e -> xuLyMaHoa());
        btn_decrypt.addActionListener(e -> xuLyGiaiMa());
        btn_save.addActionListener(e -> xuLyLuuFile());
        btn_open.addActionListener(e -> xuLyMoFile());
    }

    // =====================================
    // 2. XU LY MA HOA DES
    // =====================================
    private void xuLyMaHoa() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            String ciphertext = DESCipher.encrypt(
                plaintext, txt_key.getText()
            );

            txt_ciphertext.setText(ciphertext);

            lbl_status.setText(
                "Đã mã hóa DES. (Chưa ghi lịch sử SQL Server)"
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Mã hóa thất bại:\n" + ex.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =====================================
    // 3. XU LY GIAI MA DES
    // =====================================
    private void xuLyGiaiMa() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            String plaintext = DESCipher.decrypt(
                ciphertext, txt_key.getText()
            );

            txt_plaintext.setText(plaintext);

            lbl_status.setText(
                "Đã giải mã DES. (Chưa ghi lịch sử SQL Server)"
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n"
                    + ex.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =====================================
    // 4. LUU FILE
    // =====================================
    private void xuLyLuuFile() {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "des_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    // =====================================
    // 5. MO FILE
    // =====================================
    private void xuLyMoFile() {

        String path = FileTextIO.openText(
            this, txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // =====================================
    // 6. HAM MAIN
    // =====================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            () -> new frm_DES().setVisible(true)
        );
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
