package week_02;

import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;

/** LAB 2 - Hiển thị 50 thao tác gần nhất trong bảng dbo.crypto_history. */
public class frm_LichSu extends JFrame {
    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        taoGiaoDien();
        tbl_history.setModel(HistoryDao.emptyModel());
        loadData();
    }

    private void taoGiaoDien() {
        setTitle("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout(12, 14));
        root.setBackground(new Color(245, 248, 250));
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel title = new JLabel("LỊCH SỬ THAO TÁC - BẢNG DBO.CRYPTO_HISTORY");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        tbl_history = new JTable();
        tbl_history.setRowHeight(25);
        tbl_history.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        root.add(new JScrollPane(tbl_history), BorderLayout.CENTER);

        btn_refresh = new JButton("Tải lại");
        lbl_status = new JLabel("Đang tải...");
        lbl_status.setForeground(new Color(85, 95, 108));
        JPanel footer = new JPanel(new BorderLayout(0, 8));
        footer.setOpaque(false);
        footer.add(btn_refresh, BorderLayout.WEST);
        footer.add(lbl_status, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
        setSize(820, 470);
        setLocationRelativeTo(null);
        btn_refresh.addActionListener(e -> loadData());
    }

    /** Đọc 50 dòng mới nhất từ SQL Server. */
    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount()
                    + " dòng mới nhất từ dbo.crypto_history.");
        } catch (SQLException ex) {
            lbl_status.setText("Không đọc được lịch sử: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
}
