package week_02;

import java.awt.*;
import java.util.Arrays;
import javax.swing.*;

/** LAB 2 - Form nhập thông tin kết nối SQL Server. */
public class frm_KetNoiSQL extends JFrame {
    private JTextField txt_server, txt_port, txt_database, txt_user;
    private JPasswordField txt_password;
    private JButton btn_test, btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        taoGiaoDien();
    }

    private void taoGiaoDien() {
        setTitle("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout(12, 15));
        root.setBackground(new Color(245, 248, 250));
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel title = new JLabel("KẾT NỐI MICROSOFT SQL SERVER");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(35, 55, 75));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 7, 7, 7);
        g.fill = GridBagConstraints.HORIZONTAL;
        txt_server = new JTextField("127.0.0.1", 28);
        txt_port = new JTextField("14333", 10);
        txt_database = new JTextField("LAB2_MaHoaHienDai", 28);
        txt_user = new JTextField("lab2_user", 28);
        txt_password = new JPasswordField(28);
        addRow(form, g, 0, "Server:", txt_server);
        addRow(form, g, 1, "Port:", txt_port);
        addRow(form, g, 2, "Database:", txt_database);
        addRow(form, g, 3, "User:", txt_user);
        addRow(form, g, 4, "Password:", txt_password);
        root.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        buttons.setOpaque(false);
        btn_test = new JButton("Test Connection");
        btn_history = new JButton("Xem lịch sử");
        buttons.add(btn_test);
        buttons.add(btn_history);
        lbl_status = new JLabel("Chưa kết nối.");
        lbl_status.setForeground(new Color(85, 95, 108));
        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);
        footer.add(buttons, BorderLayout.NORTH);
        footer.add(lbl_status, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
        setSize(700, 450);
        setLocationRelativeTo(null);
        btn_test.addActionListener(e -> xuLyKetNoi());
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));
    }

    private static void addRow(JPanel form, GridBagConstraints g,
            int y, String name, JComponent value) {
        g.gridy = y;
        g.gridx = 0;
        g.weightx = 0;
        form.add(new JLabel(name), g);
        g.gridx = 1;
        g.weightx = 1;
        form.add(value, g);
    }

    private void xuLyKetNoi() {
        char[] password = txt_password.getPassword();
        try {
            int port = Integer.parseInt(txt_port.getText().trim());
            DbConfig.set(txt_server.getText().trim(), port,
                    txt_database.getText().trim(), txt_user.getText().trim(), password);
            lbl_status.setText("<html>" + DbConfig.test() + "</html>");
        } catch (Exception ex) {
            DbConfig.clear();
            lbl_status.setText("<html>Kết nối thất bại: " + ex.getMessage() + "</html>");
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
}
