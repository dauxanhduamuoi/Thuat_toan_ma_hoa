/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package week_02;

public class TestDES {

    public static void main(String[] args) throws Exception {

        String plaintext = "Xin chào Lab 2 - Mã hóa hiện đại!";
        String key = "12345678";

        String ciphertext = DESCipher.encrypt(plaintext, key);
        String decrypted = DESCipher.decrypt(ciphertext, key);

        System.out.println("Plaintext: " + plaintext);
        System.out.println("Ciphertext: " + ciphertext);
        System.out.println("Decrypted: " + decrypted);

        System.out.println(
            "Kiem tra: " +
            (plaintext.equals(decrypted) ? "PASS" : "FAIL")
        );
    }
}

